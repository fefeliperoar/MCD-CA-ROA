# Differential Growth

A simplified, clean-interface fork of [ekimroyrp/260308_DifferentialGrowth](https://github.com/ekimroyrp/260308_DifferentialGrowth) — a Three.js-based interactive 3D differential growth simulator with adaptive remeshing, timeline scrubbing, and history undo/redo. It uses a minimal black-background UI with the control panel docked to the left.

Compared to the original repository, this version:
- Uses a clean, minimal, black-background interface with the control panel docked to the left.
- Limits the base shape to `Torus`, `Sphere`, and `Cylinder`.
- Keeps only the scale sliders (`Scale X/Y/Z`) in the Shape panel and removes rotation controls.
- Removes the Mask feature entirely (no mask painting, brush controls, or mask-driven growth).
- Limits export to `Export Screenshot` (PNG) only — no OBJ/GLB export.
- Keeps the Simulation, Growth, and Material panels unchanged from the original.

## Features
- Real-time differential growth simulation on triangle meshes with adaptive loop behavior (split -> grow/repulse -> relax).
- Adaptive edge splitting/remeshing with max-vertex cap enforcement to support growing surface detail.
- Base shape library: `Torus`, `Sphere`, `Cylinder`.
- Shape setup controls: `Start Subdivision`, `Scale X/Y/Z`, `Reset Subdivision`, `Reset Scale`.
- Simulation controls: `Start/Pause`, `Reset`, `Simulation Rate`, and `Simulation Timeline` scrubbing (resume continues from scrubbed step).
- Global editing history with up to 100 undo and 100 redo states across sliders, toggles, dropdowns, and action buttons.
- Material controls: `Gradient Type` (`Displacement` or `Curvature`), gradient colors, `Gradient Contrast`, `Gradient Bias`, `Gradient Blur`, `Fresnel`, `Specular`, and `Bloom`.
- `Export Screenshot` (PNG capture of the current viewport).
- Draggable/collapsible UI with collapsible sections and custom-styled dropdown controls.
- Post-processing pipeline with bloom and FXAA.

## Getting Started
1. Install dependencies:
   - `npm install`
2. Run development server:
   - `npm run dev`
3. Build production bundle:
   - `npm run build`
4. Preview production build locally:
   - `npm run preview`
5. Run tests:
   - `npm test`

## Controls
- Camera:
  - `Wheel` = Zoom
  - `MMB` = Pan
  - `RMB` = Orbit
- Simulation:
  - `Start` runs simulation
  - `Pause` stops simulation updates and enables timeline scrubbing
  - `Reset` rebuilds the current shape setup and resets timeline history to step 0
  - `Simulation Timeline` lets you scrub through recorded steps while paused; pressing `Start` resumes from the selected step
  - `Ctrl + Z` = Undo (up to 100 steps), `Ctrl + Y` or `Ctrl + Shift + Z` = Redo (up to 100 steps)
- Shape:
  - Choose `Torus`, `Sphere`, or `Cylinder`, and configure `Start Subdivision` / `Scale X/Y/Z` before or between runs
  - `Show Mesh` toggles shaded mesh visibility, `Show Wireframe` toggles wire overlay
- Export:
  - `Export Screenshot` downloads a PNG screenshot of the current viewport

## Deployment
- **Local production preview:** `npm install`, then `npm run build` followed by `npm run preview` to inspect the compiled bundle.
- **Publish to GitHub Pages:** From a clean `main`, run `npm run build -- --base=./`. Checkout (or create) the `gh-pages` branch in a separate worktree/clone, copy everything inside `dist/` plus a `.nojekyll` marker to its root (and keep the minimal deploy layout such as `assets/`, `env/`, and `index.html`), commit with a descriptive message, `git push origin gh-pages`, then switch back to `main`.

## Credit
Based on [ekimroyrp/260308_DifferentialGrowth](https://github.com/ekimroyrp/260308_DifferentialGrowth).
